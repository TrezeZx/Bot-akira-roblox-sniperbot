
# [UGC Sniper]((https://discord.gg/3Uvcf8d9aY))
The first and best sniper, **again.**

A free UGC sniper bot for roblox that snipes limiteds.  

Unofficial tutorial: [Youtube Link](https://youtu.be/tLiNCI8bzSo)  
Mobile tutorial: [Google Docs Link](https://docs.google.com/document/d/13mYq6G7g4Q6pZBVuaNQ_H0KQJjUJpyF3/edit?usp=drivesdk&ouid=117398690012196350729&rtpof=true&sd=true)

## Table of contents
1. [Table of contents](https://github.com/J3ldo/UGC-Sniper#Table-of-contents)
2. [Premium](https://github.com/J3ldo/UGC-Sniper#Premium)
3. [Features](https://github.com/J3ldo/UGC-Sniper#Features)
4. [How to use](https://github.com/J3ldo/UGC-Sniper#how-to-use)

## [Premium](https://discord.gg/3Uvcf8d9aY)
If you aren't happy with the performance of this UGC Sniper or want a better sniper, you can buy the premium limited sniper. 
For €10, the premium limited sniper sniper has way more functionality & features, including:
  
- Check prices way faster, and faster proxies
- Search items based on RAP, projection detection
- alt account support
- blacklisted keywords
- fast price checking (119 limiteds in 0.75 seconds)
- dynamic pricing of limiteds
  ..and way more. 

## Features
* Different sniping modes afk, regular, time
* Multicookie support
* Incredible speed
* Proxy support
* Buy free and paid ugcs
* Highly customizable
* Make your own themes
* Free, and safe to use
* Windows, Mobile, Unix, Linux support

## How to use
### [Click me to watch the unofficial installation guide](https://youtu.be/tLiNCI8bzSo)

### Step 1
Install python. You first need to install python you can do this [here](https://www.python.org/download). After downloading python, you need to install the requests library. You can do this by typing "pip install requests" and "pip install discord-webhook" in the command prompt. If that doesnt work: "python -m pip install requests" and "python -m pip install discord-webhook". 

### Step 2
Click on code > download zip. This will download the program as a .zip file and after that unpack the installed limited sniper into a directory of choice.
 
### Step 3
You need to put in your roblox cookie into the cookie.txt file.

First install this repository: [Token Fetcher Link](<https://github.com/J3ldo/Roblox-Token-Fetcher>)
Then open google chrome and click on the extensions button > manage extensions > load unpacked  
Select the repository directory and click on the extension icon. Now just copy the .ROBLOSECURITY!

### Step 4
Put in the desired limiteds in limiteds.txt and seperate them with a comma.
It should look like this
Asset1, Asset2, Asset3

### Step 5
Just run the main.py file and you will see it starting to check if its free.
That's all, hope you get some good deals and some good robux, if you do make sure to star this repository.


## How to create a theme
* Copy paste and rename baseTheme
* Put your path to the theme into current theme in the config
* Edit mainlogo.txt for the logo and printText.txt for the printed text  
**TIP - For all variabled and colours see themes/required.json**
